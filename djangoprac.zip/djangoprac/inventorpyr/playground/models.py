
from django.db import models

# Create your models here.
class Student(models.Model):
    name = models.CharField(max_length=100)
    student_id = models.IntegerField() 
    sem = models.IntegerField()
    backlogs = models.IntegerField()

    def __str__(self):
        return self.name

class CourtCase(models.Model):
    CaseNumber=models.IntegerField()
    CaseName=models.CharField(max_length=150)
    FilingDate=models.DateField()
    CaseType=models.CharField(max_length=150)
    CaseStatus=models.CharField(max_length=100)
    CreateDate=models.DateTimeField(auto_now_add=True)
    UpdateDate=models.DateTimeField(auto_now=True)
