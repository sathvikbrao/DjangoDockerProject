from django.contrib import admin

# Register your models here.
from .models import Student
from .models import CourtCase
class MemberStudents(admin.ModelAdmin):
    list_display=("name","student_id","sem","backlogs")


class MemberCourtCase(admin.ModelAdmin):
    list_display=("CaseNumber","CaseName","FilingDate","CaseType","CaseStatus","CreateDate","UpdateDate")

admin.site.register(Student,MemberStudents)
admin.site.register(CourtCase,MemberCourtCase)