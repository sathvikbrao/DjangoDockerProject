import psycopg2
connection = psycopg2.connect("user=postgres password=123456 host=172.19.0.2 port=5432 dbname=mydbase")
cursor = connection.cursor()
try:
    cursor.execute("SELECT * FROM playground_student;")

    rows = cursor.fetchall()
    for row in rows:
        print(row)

except (Exception, psycopg2.Error) as error:
    print("Error executing query:", error)

finally:
    if cursor:
        cursor.close()
    if connection:
        connection.close()
